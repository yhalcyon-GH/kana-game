# たまみず・正誤フィードバック音声 導入指示

`audio` フォルダをアプリの音声アセット置き場へコピーし、
`feedback-audio-config.json` の条件に従って再生してください。

## 不正解時

次の3音声からランダムに1つ再生します。

- `wrong_oshii.mp3` — 「惜しい！」
- `wrong_ganbare.mp3` — 「頑張れ！」
- `wrong_daijoubu.mp3` — 「大丈夫！」

同じ音声が2回連続しないようにしてください。
不正解時は連続正解数を0に戻します。

## 通常正解時

次の3音声からランダムに1つ再生します。

- `correct_iine.mp3` — 「いいね！」
- `correct_seikai.mp3` — 「正解！」
- `correct_sonochoushi.mp3` — 「その調子！」

同じ音声が2回連続しないようにしてください。

## 連続正解時

連続正解の節目では、通常正解音声を再生せず、専用音声を1つだけ再生します。

### 8問モード

- 5連続正解：`streak_5_sugoi.mp3` — 「すごい！」
- 8連続正解：`streak_8_kanpeki.mp3` — 「完璧！」

### 15問モード

- 5連続正解：`streak_5_sugoi.mp3` — 「すごい！」
- 8連続正解：`streak_8_kanpeki.mp3` — 「完璧！」
- 10連続正解：`streak_10_saikou.mp3` — 「最高！」
- 15連続正解：`streak_15_perfect.mp3` — 「パーフェクト！」

## 判定順

1. 回答が不正解なら、不正解音声をランダム再生し、連続正解数を0にする。
2. 回答が正解なら、連続正解数を1増やす。
3. 現在の連続正解数がモード固有の節目に一致する場合、専用音声だけを再生する。
4. 節目でなければ、通常正解音声をランダム再生する。
5. 1回答につき音声は必ず1つだけ再生し、重ねて再生しない。
6. 次の問題へ進む際に前の音声が残っている場合は停止または再生完了を待つ。

## 実装例（TypeScript）

```ts
type QuestionMode = 8 | 15;

const incorrectIds = [
  "wrong_oshii",
  "wrong_ganbare",
  "wrong_daijoubu",
];

const normalCorrectIds = [
  "correct_iine",
  "correct_seikai",
  "correct_sonochoushi",
];

const streakAudio: Record<QuestionMode, Record<number, string>> = {
  8: {
    5: "streak_5_sugoi",
    8: "streak_8_kanpeki",
  },
  15: {
    5: "streak_5_sugoi",
    8: "streak_8_kanpeki",
    10: "streak_10_saikou",
    15: "streak_15_perfect",
  },
};

function chooseFeedbackAudio(
  isCorrect: boolean,
  currentStreak: number,
  mode: QuestionMode,
): string {
  if (!isCorrect) {
    return chooseRandomWithoutImmediateRepeat(incorrectIds);
  }

  const milestone = streakAudio[mode][currentStreak];
  if (milestone) return milestone;

  return chooseRandomWithoutImmediateRepeat(normalCorrectIds);
}
```

既存のアプリ構成に合わせてパスと再生関数は調整してください。
