# Kana-game re-recorded 7 sounds

Replacement recordings:
し / ね / は / ひ / り / わ / を

Files:
- wav/: 48 kHz mono 16-bit WAV
- webm/: Opus WebM for web app use
- manifest.json: kana-to-file mapping
- quality_report.csv: processing details
- preview_all.wav: sequential listening preview

Processing:
- split from the supplied M4A recording
- gentle stationary noise reduction
- light low-frequency cleanup and de-clicking with FFmpeg
- level normalization
- short fades to avoid edge clicks
- preserved the consonant noise that is part of し・は・ひ pronunciation

Recommended app assets:
Use webm/ for the app unless the existing project specifically requires WAV.
