Kana-game用 日本語単音音声（た〜ほ、ま〜ん）
合計31音。flatの wav/ と webm/ は、そのままpublic/audio/kana/へ配置できます。
各収録グループ別フォルダにも同じ音声とプレビューを収録しています。
処理: 前後トリミング、55Hzハイパス、noisereduceによる弱いスペクトル低減、短いフェード、音量統一。
WAV: 48kHz / mono / 16-bit PCM
WebM: Opus 64kbps / mono
「を」は発音どおり /o/ ですが、ファイル名は wo としています。
