Kana-game processed audio set: kana_sha_to_jo_processed

Source: しゃ～じょ 清音濁音6音.m4a
Kana order: しゃ、しゅ、しょ、じゃ、じゅ、じょ

Processing:
- automatic single-syllable segmentation
- removal of recording gaps and edge breaths outside each syllable
- 60 Hz high-pass filtering
- light stationary noise reduction (noisereduce)
- conservative impulse/click reduction (FFmpeg adeclick)
- active-speech level normalization
- 7 ms edge fades
- WAV: 48 kHz, mono, 16-bit PCM
- WebM: 48 kHz, mono, Opus 64 kbps

Important:
Breathy/fricative consonants such as しゃ・しゅ・しょ and ひゃ・ひゅ・ひょ
were deliberately preserved. Noise reduction was kept light.

Naming:
ぢ is saved as di.* and づ as du.* to prevent collision with じ (ji.*) and ず (zu.*).
