# Claude Code用：濁音・半濁音25音

このZIPの `audio/dakuon_handakuon` フォルダを、KanaGameの音声アセット置き場へコピーしてください。

## 収録順

が・ぎ・ぐ・げ・ご  
ざ・じ・ず・ぜ・ぞ  
だ・ぢ・づ・で・ど  
ば・び・ぶ・べ・ぼ  
ぱ・ぴ・ぷ・ぺ・ぽ

## ファイル名

- `ga.mp3` ～ `go.mp3`
- `za.mp3`, `ji.mp3`, `zu.mp3`, `ze.mp3`, `zo.mp3`
- `da.mp3`, `di.mp3`, `du.mp3`, `de.mp3`, `do.mp3`
- `ba.mp3` ～ `bo.mp3`
- `pa.mp3` ～ `po.mp3`

重複を避けるため、ファイル名では以下を使用しています。

- `じ`／`ジ` → `ji.mp3`
- `ず`／`ズ` → `zu.mp3`
- `ぢ`／`ヂ` → `di.mp3`
- `づ`／`ヅ` → `du.mp3`

完全な対応は `dakuon_handakuon_manifest.json` を参照してください。

## 実装上の注意

- ひらがなと対応するカタカナは、同じ音声を共有して構いません。
- 既存音源を置き換える場合、参照パスを
  `/audio/dakuon_handakuon/<romaji>.mp3`
  に統一してください。
- 同じ音声を重ねて再生せず、次の音声を鳴らす前に現在の再生を停止してください。

## TypeScript例

```ts
export const dakuonHandakuonAudio: Record<string, string> = {
  が: "/audio/dakuon_handakuon/ga.mp3",
  ぎ: "/audio/dakuon_handakuon/gi.mp3",
  ぐ: "/audio/dakuon_handakuon/gu.mp3",
  げ: "/audio/dakuon_handakuon/ge.mp3",
  ご: "/audio/dakuon_handakuon/go.mp3",

  ざ: "/audio/dakuon_handakuon/za.mp3",
  じ: "/audio/dakuon_handakuon/ji.mp3",
  ず: "/audio/dakuon_handakuon/zu.mp3",
  ぜ: "/audio/dakuon_handakuon/ze.mp3",
  ぞ: "/audio/dakuon_handakuon/zo.mp3",

  だ: "/audio/dakuon_handakuon/da.mp3",
  ぢ: "/audio/dakuon_handakuon/di.mp3",
  づ: "/audio/dakuon_handakuon/du.mp3",
  で: "/audio/dakuon_handakuon/de.mp3",
  ど: "/audio/dakuon_handakuon/do.mp3",

  ば: "/audio/dakuon_handakuon/ba.mp3",
  び: "/audio/dakuon_handakuon/bi.mp3",
  ぶ: "/audio/dakuon_handakuon/bu.mp3",
  べ: "/audio/dakuon_handakuon/be.mp3",
  ぼ: "/audio/dakuon_handakuon/bo.mp3",

  ぱ: "/audio/dakuon_handakuon/pa.mp3",
  ぴ: "/audio/dakuon_handakuon/pi.mp3",
  ぷ: "/audio/dakuon_handakuon/pu.mp3",
  ぺ: "/audio/dakuon_handakuon/pe.mp3",
  ぽ: "/audio/dakuon_handakuon/po.mp3",
};
```

カタカナにも、対応するひらがなと同じパスを割り当ててください。
