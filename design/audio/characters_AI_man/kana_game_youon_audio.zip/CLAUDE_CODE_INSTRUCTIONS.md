# Claude Code用：拗音33音

このZIPの `audio/youon` フォルダを、KanaGameの音声アセット置き場へコピーしてください。

## 収録順

きゃ・きゅ・きょ  
ぎゃ・ぎゅ・ぎょ  
しゃ・しゅ・しょ  
じゃ・じゅ・じょ  
ちゃ・ちゅ・ちょ  
にゃ・にゅ・にょ  
ひゃ・ひゅ・ひょ  
びゃ・びゅ・びょ  
ぴゃ・ぴゅ・ぴょ  
みゃ・みゅ・みょ  
りゃ・りゅ・りょ

## ファイル名

- `kya.mp3`, `kyu.mp3`, `kyo.mp3`
- `gya.mp3`, `gyu.mp3`, `gyo.mp3`
- `sha.mp3`, `shu.mp3`, `sho.mp3`
- `ja.mp3`, `ju.mp3`, `jo.mp3`
- `cha.mp3`, `chu.mp3`, `cho.mp3`
- `nya.mp3`, `nyu.mp3`, `nyo.mp3`
- `hya.mp3`, `hyu.mp3`, `hyo.mp3`
- `bya.mp3`, `byu.mp3`, `byo.mp3`
- `pya.mp3`, `pyu.mp3`, `pyo.mp3`
- `mya.mp3`, `myu.mp3`, `myo.mp3`
- `rya.mp3`, `ryu.mp3`, `ryo.mp3`

完全な対応は `youon_manifest.json` を参照してください。

## 実装上の注意

- ひらがなと対応するカタカナは、同じ音声を共有して構いません。
- 既存音源を置き換える場合、参照パスを
  `/audio/youon/<romaji>.mp3`
  に統一してください。
- 同じ音声を重ねて再生せず、次の音声を鳴らす前に現在の再生を停止してください。

## TypeScript例

```ts
export const youonAudio: Record<string, string> = {
  きゃ: "/audio/youon/kya.mp3",
  きゅ: "/audio/youon/kyu.mp3",
  きょ: "/audio/youon/kyo.mp3",

  ぎゃ: "/audio/youon/gya.mp3",
  ぎゅ: "/audio/youon/gyu.mp3",
  ぎょ: "/audio/youon/gyo.mp3",

  しゃ: "/audio/youon/sha.mp3",
  しゅ: "/audio/youon/shu.mp3",
  しょ: "/audio/youon/sho.mp3",

  じゃ: "/audio/youon/ja.mp3",
  じゅ: "/audio/youon/ju.mp3",
  じょ: "/audio/youon/jo.mp3",

  ちゃ: "/audio/youon/cha.mp3",
  ちゅ: "/audio/youon/chu.mp3",
  ちょ: "/audio/youon/cho.mp3",

  にゃ: "/audio/youon/nya.mp3",
  にゅ: "/audio/youon/nyu.mp3",
  にょ: "/audio/youon/nyo.mp3",

  ひゃ: "/audio/youon/hya.mp3",
  ひゅ: "/audio/youon/hyu.mp3",
  ひょ: "/audio/youon/hyo.mp3",

  びゃ: "/audio/youon/bya.mp3",
  びゅ: "/audio/youon/byu.mp3",
  びょ: "/audio/youon/byo.mp3",

  ぴゃ: "/audio/youon/pya.mp3",
  ぴゅ: "/audio/youon/pyu.mp3",
  ぴょ: "/audio/youon/pyo.mp3",

  みゃ: "/audio/youon/mya.mp3",
  みゅ: "/audio/youon/myu.mp3",
  みょ: "/audio/youon/myo.mp3",

  りゃ: "/audio/youon/rya.mp3",
  りゅ: "/audio/youon/ryu.mp3",
  りょ: "/audio/youon/ryo.mp3",
};
```

カタカナにも、対応するひらがなと同じパスを割り当ててください。
