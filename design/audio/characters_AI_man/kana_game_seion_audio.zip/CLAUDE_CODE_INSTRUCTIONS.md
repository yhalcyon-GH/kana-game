# Claude Code用：清音46音の音声

このZIPに含まれる `audio/seion` フォルダをKanaGameの音声アセット置き場へコピーしてください。

## 内容

清音46音を、1文字につき1つのMP3に分割してあります。

- あ〜お
- か〜こ
- さ〜そ
- た〜と
- な〜の
- は〜ほ
- ま〜も
- や・ゆ・よ
- ら〜ろ
- わ・を・ん

## ファイル名

ローマ字のASCIIファイル名です。

例：

- `a.mp3` — あ／ア
- `shi.mp3` — し／シ
- `chi.mp3` — ち／チ
- `tsu.mp3` — つ／ツ
- `fu.mp3` — ふ／フ
- `wo.mp3` — を／ヲ
- `n.mp3` — ん／ン

完全な対応は `seion_manifest.json` を参照してください。

## 実装上の注意

- ひらがなとカタカナは同じ発音音源を共有して構いません。
- 「お」は `o.mp3`、「を」は `wo.mp3` を使用してください。
- 「ら」は `ra.mp3` です。元の文字列にあった「ダ」は誤記として扱っています。
- 既存音源を置き換える場合は、コード内の参照パスを
  `/audio/seion/<romaji>.mp3`
  に統一してください。
- 同じ音声を重ねて再生せず、次の音を再生する前に現在の音声を停止してください。

## TypeScript例

```ts
export const seionAudio: Record<string, string> = {
  あ: "/audio/seion/a.mp3",
  い: "/audio/seion/i.mp3",
  う: "/audio/seion/u.mp3",
  え: "/audio/seion/e.mp3",
  お: "/audio/seion/o.mp3",
  か: "/audio/seion/ka.mp3",
  き: "/audio/seion/ki.mp3",
  く: "/audio/seion/ku.mp3",
  け: "/audio/seion/ke.mp3",
  こ: "/audio/seion/ko.mp3",
  さ: "/audio/seion/sa.mp3",
  し: "/audio/seion/shi.mp3",
  す: "/audio/seion/su.mp3",
  せ: "/audio/seion/se.mp3",
  そ: "/audio/seion/so.mp3",
  た: "/audio/seion/ta.mp3",
  ち: "/audio/seion/chi.mp3",
  つ: "/audio/seion/tsu.mp3",
  て: "/audio/seion/te.mp3",
  と: "/audio/seion/to.mp3",
  な: "/audio/seion/na.mp3",
  に: "/audio/seion/ni.mp3",
  ぬ: "/audio/seion/nu.mp3",
  ね: "/audio/seion/ne.mp3",
  の: "/audio/seion/no.mp3",
  は: "/audio/seion/ha.mp3",
  ひ: "/audio/seion/hi.mp3",
  ふ: "/audio/seion/fu.mp3",
  へ: "/audio/seion/he.mp3",
  ほ: "/audio/seion/ho.mp3",
  ま: "/audio/seion/ma.mp3",
  み: "/audio/seion/mi.mp3",
  む: "/audio/seion/mu.mp3",
  め: "/audio/seion/me.mp3",
  も: "/audio/seion/mo.mp3",
  や: "/audio/seion/ya.mp3",
  ゆ: "/audio/seion/yu.mp3",
  よ: "/audio/seion/yo.mp3",
  ら: "/audio/seion/ra.mp3",
  り: "/audio/seion/ri.mp3",
  る: "/audio/seion/ru.mp3",
  れ: "/audio/seion/re.mp3",
  ろ: "/audio/seion/ro.mp3",
  わ: "/audio/seion/wa.mp3",
  を: "/audio/seion/wo.mp3",
  ん: "/audio/seion/n.mp3",
};
```

カタカナについても、対応するひらがなと同じパスを割り当ててください。
