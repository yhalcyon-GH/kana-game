Kana-game用 清音「あ〜そ」音声セット

内容
- wav/: 48 kHz / mono / 16-bit PCM（編集・保管向け）
- webm/: Opus 64 kbps（Webアプリ向け）
- preview_all.wav: 15音を順番に確認するファイル
- manifest.json: Kana-gameから参照しやすい対応表

ファイル名
01_a.wav ～ 15_so.wav

処理
FFmpegのadeclickで強い瞬間ノイズを保守的に抑え、noisereduceで背景ノイズを弱く低減しました。
「し・す・せ・そ」の摩擦音が削れないことを優先し、音声内の息成分は過剰に消していません。発音間の吐息・操作音は切り出しで除外しています。

Claude Codeへの依頼例
「このZIP内のwebmファイルを public/audio/kana/ に配置し、manifest.jsonの対応に従って各かなの再生音声を置き換えてください。既存参照先がある場合はパスだけ更新し、再生テストも行ってください。」
